<!DOCTYPE html>
<html>

    <head>
    
        <title>Nouveau Client</title>
    
        <meta charset="utf-8" />
        
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <style>
               .cache{visibility: hidden}
        </style>
        <script type='application/javascript'>
        
                
            }
            $(document).ready(function(){
             $('.header').height($(window).height());
             });
        
        </script>
        <link rel="stylesheet" type="text/css" href="styles.css">
    </head>

    <body>
        <nav class="navbar navbar-expand-md">
             <a class="navbar-brand" href="#">Logo</a>
             <button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
             <span class="navbar-toggler-icon"></span>
             </button>
             <div class="collapse navbar-collapse" id="main-navigation">
             <ul class="navbar-nav">
             <li class="nav-item"><a class="nav-link" href="accueil.php">Accueil</a></li>
             <li class="nav-item"><a class="nav-link" href="categories.php">Categories</a></li>
             <li class="nav-item"><a class="nav-link" href="ventesflash.php">Ventes Flash</a></li>
             <li class="nav-item"><a class="nav-link" href="vendre.php">Vendre</a></li>
             <li class="nav-item"><a class="nav-link" href="compte.php">Mon Compte</a></li>
             <li class="nav-item"><a class="nav-link" href="panier.php">Panier</a></li>
             <li class="nav-item"><a class="nav-link" href="admin.php">Admin</a></li>
             </ul>
             </div>
        </nav>
        <div class="container-fluid features">
               <br><br>
        <h3 class="section-title">Inscrivez-vous !</h3><br><br><br>
        
            <form method="post" class="form-signin" action="addclientbdd.php" enctype="multipart/form-data" >
                <div class="form-group">
        
                    <input type="text" name="Name" id="nom" class="form-control" placeholder="Nom:" required><br>
                
                    <input type="text" name="prenom" class="form-control" placeholder="Prenom:" required><br>
                    
                    <input type="email" name="mail" class="form-control" placeholder="Adresse mail:" required><br><br>
                    
                    <input type="text" name="adresse1" class="form-control" placeholder="Adresse1:" required><br>
                    
                    <input type="text" name="adresse2" class="form-control" placeholder="Adresse2:" required><br>
                    
                    <input type="text" name="ville" class="form-control" placeholder="Ville:" required><br>
                    
                    <input type="number" name="cp" class="form-control" placeholder="Code Postal:" required><br>
                    
                    <input type="text" name="pays" class="form-control" placeholder="Pays:" required><br>
                    
                    <input type="number" name="numtel" class="form-control" placeholder="Numero de téléphone:" required><br><br>
                    
                    <input type="text" name="nomcarte" class="form-control" placeholder="Nom sur la carte:" required><br>
                    
                    <input type="number" name="numcarte" class="form-control" placeholder="Numero de carte:" required><br>
                    
                     
                    <select id="typecarte" name="typecarte"  class="form-control" placeholder="Nom de l'article:" required>
                        <option  selected disabled hidden> Type de Carte:</option>
                        <option >Visa</option>
                        <option >MasterCard</option>
                        <option>American Express</option>
                        <option >Autre</option>
                    </select> <br> 
                
                    <input type="number" name="datexp" min="2018" max="2030" class="form-control" placeholder="Date d'expiration:" required><br>
                    
                    <input type="number" name="codsec" max="999" class="form-control" placeholder="Cryptogramme visuel:" required><br><br>
                    
                    <input type="password" name="mdp"  class="form-control" placeholder="Mot de Passe:" required><br>
                    
                    <input type="password" name="mdpc"  class="form-control" placeholder="Confirmez votre mot de passe:" required><br>
                        
                    
                   

                    
                <label >
                    &nbsp;&nbsp;&nbsp;Photo de profil:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
                <input type="file" name="image" id="image" class="btn btn-primary btn-sm"/><br/>

                <input type="Submit" class="btn btn-lg btn-primary btn-block" value="Soumettre"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="Reset" class="btn btn-lg btn-primary btn-block" value="Réinitialiser">
            </div>
         </form>
           
        </div>  
    </body>
    <footer class="page-footer">
     
    <p>
     37, quai de Grenelle, 75015 Paris, France 
     info@webDynamique.ece.fr 
     +33 01 02 03 04 05 
     +33 01 03 02 05 04
     </p>
        
</footer>
</html>