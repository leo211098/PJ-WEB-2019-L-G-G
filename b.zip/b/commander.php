<?php
   session_start();
if(isset($_SESSION['panier']) && sizeof($_SESSION['panier']) >0)
        {
            //Task to do
            
         }
    else{
            header('Location: panier.php'); //redirect URL
        }
?>

<!DOCTYPE html>
<html>
<head>
 <title>pagepro</title>
 <meta charset="utf-8"/>
    
    
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <link rel="stylesheet" type="text/css" href="styles.css">
    
    <script type="text/javascript">
     $(document).ready(function(){
     $('.header').height($(window).height());
     });
    </script>
    
</head>
<body>
    <nav class="navbar navbar-expand-md">
 <a class="navbar-brand" href="#">Logo</a>
 <button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
 <span class="navbar-toggler-icon"></span>
 </button>
 <div class="collapse navbar-collapse" id="main-navigation">
 <ul class="navbar-nav">
 <li class="nav-item"><a class="nav-link" href="accueil.php">Accueil</a></li>
 <li class="nav-item"><a class="nav-link" href="categories.php">Categories</a></li>
 <li class="nav-item"><a class="nav-link" href="ventesflash.php">Ventes Flash</a></li>
 <li class="nav-item"><a class="nav-link" href="vendre.php">Vendre</a></li>
 <li class="nav-item"><a class="nav-link" href="compte.php">Mon Compte</a></li>
 <li class="nav-item"><a class="nav-link" href="panier.php">Panier</a></li>
 <li class="nav-item"><a class="nav-link" href="admin.php">Admin</a></li>
 </ul>
 </div>
</nav>
    
    <div class="container-fluid features">
<?php
            
            $database = "AmazonECE";
            $db_handle = mysqli_connect('localhost', 'root', 'root');
            $db_found = mysqli_select_db($db_handle, $database);
            if ($db_found)
             {
                $sql = "";
                foreach($_SESSION['panier'] as $item) {
                    $sql .="UPDATE `Article` SET `Qt` = `Qt` - 1 WHERE `Id` = '". $item ."' and `Qt` > 0;";
                }
                if (mysqli_multi_query($db_handle, $sql))
                {
                  do
                    {
                    // Store first result set
                    if ($res=mysqli_store_result($db_handle)) {
                      // Fetch one and one row
                      while ($data=mysqli_fetch_assoc($res))
                        {
                          
                      }
                      // Free result set
                      mysqli_free_result($res);
                      }
                    }
                  while (mysqli_next_result($db_handle));
                }
          
       
    }
    else {
        echo "Database not found";
    }
        mysqli_close($db_handle);

     



    //foreach($_SESSION['panier'] as $item) {
         //           unset($item);
            //    }
unset($_SESSION['panier']);
$_SESSION['panier']=array();
        
     
        $header="MIME-Version: 1.0\r\n";
$header.=' From : "ECE-Amazon" <ECE-Amazon>' . "\n";
$header.= 'Content-Type:text/html; charset="utf-8"' . "\n";
$header.= 'Content-Transfer-Encoding : 8bit';

$message='

<html>

	<body>
		<div align="center">
			Merci de votre commande ! 
			 <br/>
			 Votre colis sera livré dans la semaine.
			 <br/>
			 <img src="img/site/commande.jpg">
			 <br/>

		</div>
	</body>

</html>
';
mail( $_SESSION['utilisateur'], "Confirmation de commande", $message, $header);

echo "<br><br><br><h5>Votre commande a bien été prise en compte, un mail vous a été envoyé.</h5><br><br><br>";
        
        
?>
    </div>
</body>
    
<footer class="page-footer">
     
    <p>
     37, quai de Grenelle, 75015 Paris, France 
     info@webDynamique.ece.fr 
     +33 01 02 03 04 05 
     +33 01 03 02 05 04
     </p>
        
</footer>
    
</html>

