<!DOCTYPE html>
<html>

    <head>
    
        <title>Nouvel article</title>
    
        <meta charset="utf-8" />
        
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <style>
               .cache{visibility: hidden}
        </style>
        <script type='application/javascript'>
        function afficher(){
                var x=document.getElementById("cat").value;
                switch(x)
                    {
                        case "Musique":
                            
                            document.getElementById("liv").className="cache";
                            document.getElementById("SL").className="cache";
                            document.getElementById("vetement").className="cache";
                            document.getElementById("mus").className="";
                            break;
                        case "Livre":
                            document.getElementById("liv").className="";
                            document.getElementById("SL").className="cache";
                            document.getElementById("vetement").className="cache";
                            document.getElementById("mus").className="cache";
                            break;
                        case"SL":
                            document.getElementById("liv").className="cache";
                            document.getElementById("SL").className="";
                            document.getElementById("vetement").className="cache";
                            document.getElementById("mus").className="cache";
                            break;
                        case "vetement":
                            document.getElementById("liv").className="cache";
                            document.getElementById("SL").className="cache";
                            document.getElementById("vetement").className="";
                            document.getElementById("mus").className="cache";
                            break;
                            
                    }
                
            }
            $(document).ready(function(){
             $('.header').height($(window).height());
             });
        
        </script>
        <link rel="stylesheet" type="text/css" href="styles.css">
    </head>

    <body>
        <nav class="navbar navbar-expand-md">
             <a class="navbar-brand" href="#">Logo</a>
             <button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#main-navigation">
             <span class="navbar-toggler-icon"></span>
             </button>
             <div class="collapse navbar-collapse" id="main-navigation">
             <ul class="navbar-nav">
             <li class="nav-item"><a class="nav-link" href="accueil.php">Accueil</a></li>
             <li class="nav-item"><a class="nav-link" href="categories.php">Categories</a></li>
             <li class="nav-item"><a class="nav-link" href="ventesflash.php">Ventes Flash</a></li>
             <li class="nav-item"><a class="nav-link" href="vendre.php">Vendre</a></li>
             <li class="nav-item"><a class="nav-link" href="compte.php">Mon Compte</a></li>
             <li class="nav-item"><a class="nav-link" href="panier.php">Panier</a></li>
             <li class="nav-item"><a class="nav-link" href="admin.php">Admin</a></li>
             </ul>
             </div>
        </nav>
        <div class="container-fluid features">
            <br><br>
        <h3 class="section-title">Ajoutez un nouvel article !</h3><br><br><br>
        
            <form method="post" class="form-signin" action="addarticlebdd.php" enctype="multipart/form-data" >
                <div class="form-group">
        
                    <input type="text" name="Name" id="nom" class="form-control" placeholder="Nom de l'article:" required><br>
                    
                
                
                    <input type="number" name="quantite" class="form-control" placeholder="Quantité de vente:" required><br><br>

                    <select id="cat" name="cat" onchange= "afficher()"class="form-control"  required >
                        <option  selected disabled hidden>Sélectionnez la catégorie</option>
                        <option value="Livre" >Livre</option>
                        <option value="Musique" >Musique</option>
                        <option value="SL">Sport et Loisir</option>
                        <option value="vetement">Vetement</option>
                    </select>

                    <div class="row">
                        <div  class="col-lg-3">
                            <br>
                            <div id="mus" class="cache">
                                
                                <input type="text" name="artiste" class="form-control" placeholder="Artiste:" ><br><br>
                                
                                <input type="text" name="album" class="form-control" placeholder="Album:"><br><br>
                                
                                <input type="text" name="genreM" class="form-control" placeholder="Genre:"><br>
                            </div>

                        </div>
                            <div class="col-lg-3">
                                <br>
                                <div id="liv" class="cache" >
                                    
                                    <input type="text" name="auteur" class="form-control" placeholder="Auteur:"><br><br>
                                    
                                    <input type="text" name="editeur" class="form-control" placeholder="Editeur:"><br><br>
                                    
                                    <input type="text" name="genreL" class="form-control" placeholder="Genre:"><br>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <br>
                                <div id="SL" class="cache" >
                                    <input type="text" name="brand" class="form-control" placeholder="Marque:"><br><br>
                                    <input type="text" name="article" class="form-control" placeholder="Article:"><br><br>
                                    
                                    <input type="text" name="couleur" class="form-control" placeholder="Couleur:"><br>

                                </div>
                            </div>
                            <div class="col-lg-3">
                                <br>
                                <div id="vetement" class="cache">
                                    <select id="sex" name="sex" class="form-control" >
                                        <option  selected disabled hidden>Sexe</option>
                                        <option>Homme</option>
                                        <option>Femme</option>
                                        <option>Enfant</option>
                                    </select><br><br>
                                    
                                    <input type="text" name="piece"  class="form-control" placeholder="Pièce:"><br><br>
                                    
                                    <input type="text" name="marqueV" class="form-control" placeholder="Marque:"><br>

                                </div>
                            </div>
                        </div>
                    
                    <br>

                    <br>

                    <input type="text" name="description" class="form-control" placeholder="Description:" required>
                
                <br>
                <input type="number" name="prix" class="form-control" placeholder="Prix:" required>
                <br>
                <label >
                    &nbsp;&nbsp;&nbsp;Image du produit:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
                <input type="file" name="image" id="image" class="btn btn-primary btn-sm "/><br/>

                <input type="Submit" class="btn btn-lg btn-primary btn-block" value="Soumettre"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="Reset" class="btn btn-lg btn-primary btn-block" value="Réinitialiser">
            </div>
         </form>
           
        </div>  
    </body>
    <footer class="page-footer">
     
    <p>
     37, quai de Grenelle, 75015 Paris, France 
     info@webDynamique.ece.fr 
     +33 01 02 03 04 05 
     +33 01 03 02 05 04
     </p>
        
</footer>
</html>